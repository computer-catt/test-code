﻿using System;
using Cyotek.Data.Nbt;

namespace Servers.dat_Maker
{
	internal class Program
	{
		private static void Main(string[] args)
		{
			NbtDocument nbtDocument = NbtDocument.LoadDocument("servers.dat");
			TagCompound documentRoot = nbtDocument.DocumentRoot;
			documentRoot.Name = "Level";
			TagList tagList;
			try
			{
				tagList = (TagList)documentRoot.Value.Add("servers", 9, 10);
			}
			catch
			{
				tagList = documentRoot.GetList("servers");
			}
			for (;;)
			{
				Console.WriteLine("Select a below option:");
				Console.WriteLine("A: Adds a server to the servers.dat");
				Console.WriteLine("R: Removes a server from the servers.dat");
				Console.WriteLine("C: Creates the servers.dat");
				Console.WriteLine("L: Lists all of the servers and their ip's\n");
				Console.Write("Option [A/R/C/L]: ");
				string text = Console.ReadLine().ToUpper();
				string text2 = text.Trim();
				string a = text2;
				if (!(a == "A"))
				{
					if (!(a == "R"))
					{
						if (!(a == "C"))
						{
							if (!(a == "L"))
							{
								Console.Clear();
								Console.ForegroundColor = ConsoleColor.Red;
								Console.WriteLine("Error: Expected A/R. Got \"" + text + "\"");
								Console.ForegroundColor = ConsoleColor.White;
								Console.WriteLine("\n");
							}
							else
							{
								Console.WriteLine();
								Console.WriteLine("---------------");
								Console.WriteLine();
								Console.WriteLine("Servers:\n");
			
								int num = 1;
								foreach (string text3 in documentRoot.GetList("servers").Value.ToString().Split(new char[]{',',']','['}))
								{
									if (text3.Trim().Length == 0)
									{
										num++;
										if (num % 2 == 0)
										{
											Console.WriteLine((num / 2).ToString() + ":");
											Console.WriteLine("Ip: " + text3.Trim());
										}
										if (num % 2 == 1)
										{
											Console.WriteLine("Name: " + text3.Trim());
											Console.WriteLine("");
										}
									}
								}
								Console.WriteLine("---------------");
								Console.WriteLine();
							}
						}
						else
						{
							nbtDocument.Save("servers.dat");
							Console.Clear();
							Console.ForegroundColor = ConsoleColor.Green;
							Console.WriteLine("Done creating the servers.dat!\n");
							Console.ForegroundColor = ConsoleColor.White;
						}
					}
					else
					{
						Console.WriteLine("\nServers:\n\n");
						int num2 = 1;
						foreach (string text4 in documentRoot.GetList("servers").Value.ToString().Split(new char[]{',',']','['}))
						{
							if (text4.Trim().Length == 0)
							{
								num2++;
								if (num2 % 2 == 0)
								{
									Console.WriteLine("Index " + (num2 / 2 - 1).ToString() + ":");
									Console.WriteLine("   Ip: " + text4.Trim());
								}
								if (num2 % 2 == 1)
								{
									Console.WriteLine("   Name: " + text4.Trim());
									Console.WriteLine("");
								}
							}
						}
						Console.WriteLine("You can also say 'all' or 'clear' to delete all servers!");
						Console.Write("Send the index of the server you want to delete: ");
						string text5 = Console.ReadLine();
						if (text5 == "all" || text5 == "clear")
						{
							documentRoot.GetList("servers").Value.Clear();
							Console.ForegroundColor = ConsoleColor.Green;
							Console.WriteLine("\nAll servers deleted successfully!\nMake sure to create the dat!\n");
							Console.ForegroundColor = ConsoleColor.White;
						}
						else
						{
							try
							{
								documentRoot.GetList("servers").Value.RemoveAt(int.Parse(text5));
								Console.ForegroundColor = ConsoleColor.Green;
								Console.WriteLine("\nServer deleted successfully!\nMake sure to create the dat!\n");
								Console.ForegroundColor = ConsoleColor.White;
							}
							catch
							{
								Console.Clear();
								Console.ForegroundColor = ConsoleColor.Red;
								Console.WriteLine("Error: Expected Number. Got \"" + text5 + "\"");
								Console.ForegroundColor = ConsoleColor.White;
								Console.WriteLine("\n");
							}
						}
					}
				}
				else
				{
					string text6;
					for (;;)
					{
						Console.WriteLine("\n");
						Console.Write("Server Name: ");
						text6 = Console.ReadLine().Trim();
						if (text6 != "")
						{
							break;
						}
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Error: Server name cannot be blank!");
						Console.ForegroundColor = ConsoleColor.White;
						Console.WriteLine("\n");
					}
					string text7;
					for (;;)
					{
						Console.Write("Server Ip: ");
						text7 = Console.ReadLine().Trim();
						bool flag9 = text7 == "";
						if (!flag9)
						{
							break;
						}
						Console.ForegroundColor = ConsoleColor.Red;
						Console.WriteLine("Error: Server ip cannot be blank!");
						Console.ForegroundColor = ConsoleColor.White;
						Console.WriteLine("\n");
					}
					Console.Write("\n");
					TagCompound tagCompound = (TagCompound)tagList.Value.Add(10);
					tagCompound.Name = text6;
					tagCompound.Value.Add("ip", text7);
					tagCompound.Value.Add("name", text6);
					Console.ForegroundColor = ConsoleColor.Green;
					Console.WriteLine("Server added successfully!\n");
					Console.ForegroundColor = ConsoleColor.White;
				}
			}
		}
	}
}
